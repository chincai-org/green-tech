/**
 * Sprite for decreasing pollution level
 * @class
 * @extends {BaseSprite}
 */
class Tree extends BaseSprite {
    constructor(x, y) {
        super({ x, y, color: "#00ff00" });
    }

    _update() {
        // TODO: tree update
    }
}
